import React, { useState, useEffect, useMemo } from 'react';
import { MenuItem, CartItem, ClientData, OrderData } from '../types';
import { Icon } from './Icon';
import { GoogleDeliveryMap } from './GoogleDeliveryMap';
import { WhatsAppOrderParserModal } from './WhatsAppOrderParserModal';
import { CustomerObjectionsModal } from './CustomerObjectionsModal';
import { printOrderTicket } from '../utils/printTicket';
import { ClientContactLookup } from './ClientContactLookup';

interface PosWizardProps {
  posStep: 1 | 2 | 3;
  setPosStep: (step: 1 | 2 | 3) => void;
  menu: Record<string, MenuItem[]>;
  allMenuItems: MenuItem[];
  activeCategory: string;
  setActiveCategory: (cat: string) => void;
  cart: CartItem[];
  setCart: React.Dispatch<React.SetStateAction<CartItem[]>>;
  addToCart: (item: MenuItem, selectedToppings: any[], initialQty?: number) => void;
  updateQuantity: (cartId: string, delta: number) => void;
  cartTotal: number;
  orderType: string;
  setOrderType: (type: string) => void;
  paymentMethod: string;
  setPaymentMethod: (pm: string) => void;
  cashProvided: string;
  setCashProvided: (cash: string) => void;
  orderNotes: string;
  setOrderNotes: React.Dispatch<React.SetStateAction<string>>;
  clientInfo: { phone: string; name: string; address: string; zone: string; tableNumber?: number | string; assignedWaiter?: string; assignedDriver?: string; assignedDriverId?: string };
  setClientInfo: React.Dispatch<React.SetStateAction<any>>;
  allClients: ClientData[];
  matchingClients: ClientData[];
  showClientDropdown: boolean;
  setShowClientDropdown: (show: boolean) => void;
  isScheduled: boolean;
  setIsScheduled: (scheduled: boolean) => void;
  scheduledTime: string;
  setScheduledTime: (time: string) => void;
  editingOrder: OrderData | null;
  clearForm: () => void;
  handleCheckout: (returnToKitchen?: boolean) => void;
  isSubmitting: boolean;
  setToppingModal: (modal: { isOpen: boolean; item: any; selectedToppings: any[]; quantity: number }) => void;
  setVoiceOrderModalOpen: (open: boolean) => void;
  showMessage: (msg: string, type?: 'success' | 'error') => void;
  orders?: OrderData[];
  th?: any;
  db?: any;
  appId?: string;
}

const COMMON_NOTE_CHIPS = [
  'Bien tostada',
  'Masa fina',
  'Sin orégano',
  'Sin cebolla',
  'Poco queso',
  'Cortar en 8',
  'Tocar timbre'
];

const ORDER_TYPES = [
  { id: 'Local', label: 'Mostrador', icon: 'storefront', color: 'from-purple-600 to-indigo-600' },
  { id: 'Mesa', label: 'Mesa / Salón', icon: 'table_restaurant', color: 'from-blue-600 to-cyan-600' },
  { id: 'Envío', label: 'Delivery / Envío', icon: 'two_wheeler', color: 'from-amber-600 to-orange-600' },
];

const PAYMENT_METHODS = [
  { id: 'Efectivo', label: 'Efectivo', icon: 'payments', badge: '💵' },
  { id: 'Débito', label: 'Débito', icon: 'credit_card', badge: '💳' },
  { id: 'Crédito', label: 'Crédito', icon: 'credit_card', badge: '💳' },
  { id: 'Transferencia', label: 'Transf.', icon: 'account_balance', badge: '📱' },
  { id: 'A confirmar', label: 'A Confirmar', icon: 'help_outline', badge: '⚡' },
];

export const PosWizard: React.FC<PosWizardProps> = ({
  menu,
  allMenuItems,
  activeCategory,
  setActiveCategory,
  cart,
  addToCart,
  updateQuantity,
  cartTotal,
  orderType,
  setOrderType,
  paymentMethod,
  setPaymentMethod,
  cashProvided,
  setCashProvided,
  orderNotes,
  setOrderNotes,
  clientInfo,
  setClientInfo,
  allClients,
  matchingClients,
  showClientDropdown,
  setShowClientDropdown,
  isScheduled,
  setIsScheduled,
  scheduledTime,
  setScheduledTime,
  editingOrder,
  clearForm,
  handleCheckout,
  isSubmitting,
  setToppingModal,
  setVoiceOrderModalOpen,
  showMessage,
  orders = [],
  th,
  db,
  appId,
}) => {
  const [productSearch, setProductSearch] = useState('');
  const [isWhatsAppParserOpen, setIsWhatsAppParserOpen] = useState(false);
  const [isObjectionsOpen, setIsObjectionsOpen] = useState(false);
  const [showMobileComanda, setShowMobileComanda] = useState(false);
  const [showMapModal, setShowMapModal] = useState(false);
  
  // Mandatory print flag: obligar a imprimir antes de pasar a KDS
  const [ticketPrinted, setTicketPrinted] = useState(false);

  // Delivery Drivers & Sequential Round-Robin Logic (1 Fefo, 2 Caetano, 3 Samuel)
  const DRIVERS = [
    { number: 1, name: 'Fefo', id: 'delivery1', label: '1. Fefo' },
    { number: 2, name: 'Caetano', id: 'delivery2', label: '2. Caetano' },
    { number: 3, name: 'Samuel', id: 'delivery3', label: '3. Samuel' },
  ];

  const suggestedDriver = useMemo(() => {
    if (!orders || orders.length === 0) return DRIVERS[0];
    const assignedDeliveryOrders = orders
      .filter(o => o.assignedDriver && ['envío', 'delivery'].includes(String(o.type || '').toLowerCase()))
      .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

    if (assignedDeliveryOrders.length === 0) return DRIVERS[0];

    const last = (assignedDeliveryOrders[0].assignedDriver || '').trim().toLowerCase();
    if (last.includes('fefo')) return DRIVERS[1]; // 2 Caetano
    if (last.includes('caetano')) return DRIVERS[2]; // 3 Samuel
    if (last.includes('samuel')) return DRIVERS[0]; // 1 Fefo

    return DRIVERS[0];
  }, [orders]);

  // When switching to Delivery, auto-assign suggested driver if not set
  useEffect(() => {
    if (['envío', 'delivery'].includes(orderType.toLowerCase()) && !clientInfo.assignedDriver) {
      setClientInfo((prev: any) => ({
        ...prev,
        assignedDriver: suggestedDriver.name,
        assignedDriverId: suggestedDriver.id
      }));
    }
  }, [orderType, suggestedDriver]);

  // Reset print status when cart or order core details change
  useEffect(() => {
    setTicketPrinted(false);
  }, [cart, orderType, clientInfo.tableNumber, clientInfo.name, clientInfo.address, paymentMethod]);

  // Calculate live change for cash
  const cashNum = parseFloat(cashProvided) || 0;
  const changeDue = cashNum > 0 ? Math.max(0, cashNum - cartTotal) : 0;
  const missingCash = cashNum > 0 && cashNum < cartTotal ? cartTotal - cashNum : 0;
  const totalItemCount = cart.reduce((s, i) => s + (i.quantity || 1), 0);

  // Cart item count map for highlighting products already added
  const cartItemQuantities = useMemo(() => {
    const map: Record<string, number> = {};
    cart.forEach(item => {
      if (item.id) {
        map[item.id] = (map[item.id] || 0) + (item.quantity || 1);
      }
    });
    return map;
  }, [cart]);

  // Filter products by search or category
  const filteredProducts = useMemo(() => {
    const list = activeCategory === 'TODOS' ? allMenuItems : (menu[activeCategory] || []);
    if (!productSearch.trim()) return list;
    const q = productSearch.toLowerCase();
    return list.filter(item => item.name.toLowerCase().includes(q) || (item.desc && item.desc.toLowerCase().includes(q)));
  }, [activeCategory, allMenuItems, menu, productSearch]);

  const handleAddNoteChip = (chip: string) => {
    setOrderNotes(prev => {
      const current = prev.trim();
      if (!current) return chip;
      if (current.toLowerCase().includes(chip.toLowerCase())) return current;
      return `${current}, ${chip}`;
    });
  };

  const handleSelectClient = (c: ClientData) => {
    setClientInfo({
      ...clientInfo,
      name: c.name || '',
      phone: c.phone || '',
      address: c.address || '',
      zone: c.zone || ''
    });
    if (c.address) setOrderType('Envío');
    setShowClientDropdown(false);
    showMessage(`Cliente ${c.name} cargado`);
  };

  // Build current order object for printing
  const buildCurrentOrderForPrint = (): OrderData => {
    const isMesa = orderType === 'Mesa';
    const tableNum = isMesa ? (clientInfo.tableNumber || 1) : null;
    const waiterName = isMesa ? (clientInfo.assignedWaiter || 'Moza 1') : null;
    const finalDriver = clientInfo.assignedDriver || null;
    const finalDriverId = clientInfo.assignedDriverId || null;

    return {
      firestoreId: editingOrder?.firestoreId || 'temp',
      id: String(editingOrder ? editingOrder.id : (orders && orders.length > 0 ? Math.max(...orders.map(o => Number(o.id) || 0)) + 1 : 1)),
      type: orderType || 'Local',
      reference: orderType === 'Envío' ? 'ENVÍO' : (orderType === 'Mesa' ? `MESA #${tableNum}` : 'LOCAL'),
      client: {
        name: isMesa 
          ? (clientInfo.name ? `${clientInfo.name} (Mesa #${tableNum})` : `Mesa #${tableNum}`) 
          : (clientInfo.name || 'CONSUMIDOR FINAL'),
        phone: isMesa ? 'N/A' : (clientInfo.phone || 'N/A'),
        address: isMesa ? 'N/A' : (clientInfo.address || 'N/A'),
        zone: isMesa ? 'N/A' : (clientInfo.zone || 'N/A'),
        tableNumber: tableNum,
        assignedWaiter: waiterName
      },
      tableNumber: tableNum,
      assignedWaiter: waiterName,
      items: cart.map(it => ({
        id: it.id || 'N/A',
        name: it.name || 'Item',
        price: it.price || 0,
        finalPrice: it.finalPrice || it.price || 0,
        quantity: it.quantity || 1,
        selectedToppings: it.selectedToppings || [],
        isPortion: it.isPortion || false
      })),
      total: cartTotal,
      paymentMethod: paymentMethod || 'Efectivo',
      cashProvided: paymentMethod === 'Efectivo' ? (parseFloat(cashProvided) || 0) : 0,
      status: 'Preparando',
      createdAt: editingOrder ? editingOrder.createdAt : Date.now(),
      time: editingOrder ? editingOrder.time : new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isScheduled: isScheduled,
      scheduledTime: isScheduled && scheduledTime ? Date.now() : null,
      notes: orderNotes,
      assignedDriver: finalDriver,
      assignedDriverId: finalDriverId,
    };
  };

  // Trigger ticket printing
  const handlePrintTicket = (): boolean => {
    if (cart.length === 0) {
      showMessage("Cargue al menos un producto a la comanda antes de imprimir", "error");
      return false;
    }
    const orderData = buildCurrentOrderForPrint();
    printOrderTicket(orderData);
    setTicketPrinted(true);
    showMessage("Imprimiendo comanda térmica...");
    return true;
  };

  // Submit to KDS with strict enforcement of printing
  const handleDispatchToKds = (autoPrint = false) => {
    if (cart.length === 0) {
      showMessage("El carrito está vacío. Agregue productos antes de enviar a cocina.", "error");
      return;
    }

    if (orderType === 'Mesa' && !clientInfo.tableNumber) {
      showMessage("Debe seleccionar el número de mesa", "error");
      return;
    }

    // Si autoPrint o no ha impreso el ticket, se ejecuta la impresión obligatoria
    if (!ticketPrinted || autoPrint) {
      const printed = handlePrintTicket();
      if (!printed) return;
    }

    // Enviar a KDS
    handleCheckout(false);
    setTicketPrinted(false);
    setShowMobileComanda(false);
  };

  // WhatsApp Order Parser Handler
  const handleApplyWhatsAppOrder = (data: {
    items: { item: MenuItem; quantity: number; selectedToppings: any[] }[];
    clientInfo: { name: string; phone: string; address: string; zone: string };
    orderType: string;
    paymentMethod: string;
    cashProvided: string;
    notes: string;
  }) => {
    if (data.items.length > 0) {
      data.items.forEach(it => {
        addToCart(it.item, it.selectedToppings, it.quantity);
      });
    }
    if (data.clientInfo.name || data.clientInfo.phone || data.clientInfo.address) {
      setClientInfo((prev: any) => ({ ...prev, ...data.clientInfo }));
    }
    if (data.orderType) setOrderType(data.orderType);
    if (data.paymentMethod) setPaymentMethod(data.paymentMethod);
    if (data.cashProvided) setCashProvided(data.cashProvided);
    if (data.notes) {
      handleAddNoteChip(data.notes);
    }
    showMessage("Pedido de WhatsApp aplicado exitosamente");
  };

  // Categories list
  const categoryKeys = useMemo(() => {
    const keys = Object.keys(menu);
    return ['TODOS', ...keys];
  }, [menu]);

  return (
    <div className="h-full flex flex-col lg:flex-row bg-[#040108] text-slate-100 select-none overflow-hidden relative">
      {/* ========================================================================= */}
      {/* LEFT / CENTER PANEL: PRODUCT CATALOG & CATEGORIES & QUICK SEARCH         */}
      {/* ========================================================================= */}
      <div className="flex-1 flex flex-col h-full overflow-hidden border-b lg:border-b-0 lg:border-r border-purple-500/20 bg-[#05020c]">
        {/* Top Control Bar: Search + Quick Tools (WhatsApp, Objections, Voice, Clear) */}
        <div className="px-3 py-2.5 bg-[#080314] border-b border-purple-500/20 flex flex-wrap items-center justify-between gap-2 shrink-0 shadow-md">
          {/* Search Box */}
          <div className="relative flex-1 min-w-[200px] max-w-md">
            <Icon name="search" size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-purple-400/80" />
            <input
              type="text"
              placeholder="Buscar producto por nombre o descripción (ej: fainá, muzza, coca)..."
              value={productSearch}
              onChange={e => setProductSearch(e.target.value)}
              className="w-full pl-9 pr-8 py-2 bg-[#040108] border border-purple-500/30 rounded-xl text-xs font-black text-white placeholder:text-slate-500 outline-none focus:border-purple-400 transition-all focus:ring-1 focus:ring-purple-400/30"
            />
            {productSearch && (
              <button
                type="button"
                onClick={() => setProductSearch('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-0.5"
              >
                <Icon name="close" size={14} />
              </button>
            )}
          </div>

          {/* Action Tools */}
          <div className="flex items-center gap-1.5 shrink-0 ml-auto">
            {/* Pegar de WhatsApp */}
            <button
              type="button"
              onClick={() => setIsWhatsAppParserOpen(true)}
              className="px-2.5 py-2 bg-[#120824] hover:bg-[#1f0d3d] border border-purple-500/30 text-purple-200 rounded-xl text-[10px] font-black uppercase flex items-center gap-1.5 transition-all shadow-xs cursor-pointer hover:border-purple-400"
              title="Pegar comanda recibida por WhatsApp para autocompletar"
            >
              <Icon name="content_paste" size={14} className="text-purple-400" />
              <span className="hidden sm:inline">Pegar WhatsApp</span>
            </button>

            {/* Asistente de Objeciones */}
            <button
              type="button"
              onClick={() => setIsObjectionsOpen(true)}
              className="px-2.5 py-2 bg-[#0e112b] hover:bg-[#161c47] border border-blue-500/30 text-blue-200 rounded-xl text-[10px] font-black uppercase flex items-center gap-1.5 transition-all shadow-xs cursor-pointer hover:border-blue-400"
              title="Guía rápida para objeciones de clientes y sugerencias"
            >
              <Icon name="tips_and_updates" size={14} className="text-blue-400" />
              <span className="hidden sm:inline">Objeciones</span>
            </button>

            {/* Pedido por Voz */}
            <button
              type="button"
              onClick={() => setVoiceOrderModalOpen(true)}
              className="px-2.5 py-2 bg-[#20081e] hover:bg-[#330d30] border border-pink-500/30 text-pink-200 rounded-xl text-[10px] font-black uppercase flex items-center gap-1.5 transition-all shadow-xs cursor-pointer hover:border-pink-400"
              title="Tomar pedido dictando por voz con IA"
            >
              <Icon name="mic" size={14} className="text-pink-400" />
              <span className="hidden md:inline">Voz</span>
            </button>

            {/* Limpiar Formulario */}
            {cart.length > 0 && (
              <button
                type="button"
                onClick={clearForm}
                className="px-2.5 py-2 bg-red-950/40 hover:bg-red-900/60 border border-red-500/30 text-red-200 rounded-xl text-[10px] font-black uppercase flex items-center gap-1 transition-all shadow-xs cursor-pointer"
                title="Vaciar la comanda actual"
              >
                <Icon name="delete_sweep" size={14} className="text-red-400" />
                <span className="hidden xl:inline">Limpiar</span>
              </button>
            )}

            {/* Toggle Comanda en Móvil */}
            <button
              type="button"
              onClick={() => setShowMobileComanda(true)}
              className="lg:hidden px-3 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-xl text-xs font-black uppercase flex items-center gap-1.5 shadow-md shadow-purple-600/30 cursor-pointer"
            >
              <Icon name="receipt_long" size={15} />
              <span>Ver Comanda ({totalItemCount})</span>
              <span className="ml-1 px-1.5 py-0.5 bg-black/40 rounded-lg text-[10px] font-mono">${cartTotal}</span>
            </button>
          </div>
        </div>

        {/* Categories Bar */}
        <div className="px-3 py-2 bg-[#06020e] border-b border-purple-500/15 overflow-x-auto no-scrollbar flex items-center gap-1.5 shrink-0">
          {categoryKeys.map(cat => {
            const isSelected = activeCategory === cat;
            const count = cat === 'TODOS' ? allMenuItems.length : (menu[cat] || []).length;
            return (
              <button
                key={cat}
                type="button"
                onClick={() => setActiveCategory(cat)}
                className={`px-3 py-1.5 rounded-xl font-black text-[11px] uppercase tracking-wider transition-all shrink-0 flex items-center gap-1.5 cursor-pointer border ${
                  isSelected
                    ? 'bg-purple-600 text-white border-purple-400 shadow-md shadow-purple-600/30 ring-1 ring-purple-400/50'
                    : 'bg-[#0f0721] text-slate-300 hover:text-white hover:bg-[#1a0c3b] border-purple-500/20 hover:border-purple-400'
                }`}
              >
                <span>{cat}</span>
                <span className={`text-[9px] px-1.5 py-0.2 rounded-full font-mono ${isSelected ? 'bg-white/20 text-white' : 'bg-purple-950 text-purple-300'}`}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Product Cards Grid */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-4 custom-scrollbar">
          {filteredProducts.length === 0 ? (
            <div className="h-48 flex flex-col items-center justify-center text-center p-6 text-slate-400 space-y-2">
              <Icon name="search_off" size={36} className="text-purple-400/50" />
              <p className="text-sm font-bold">No se encontraron productos para "{productSearch}"</p>
              <button
                type="button"
                onClick={() => { setProductSearch(''); setActiveCategory('TODOS'); }}
                className="text-xs text-purple-400 hover:underline font-black uppercase mt-1 cursor-pointer"
              >
                Ver todos los productos
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-2.5 sm:gap-3">
              {filteredProducts.map(item => {
                const qtyInCart = cartItemQuantities[item.id] || 0;
                const requiresToppings = item.hasToppings || item.isMeter;

                return (
                  <div
                    key={item.id}
                    onClick={() => {
                      if (requiresToppings) {
                        setToppingModal({ isOpen: true, item, selectedToppings: [], quantity: 1 });
                      } else {
                        addToCart(item, []);
                      }
                    }}
                    className={`group relative p-3 rounded-2xl bg-[#0b0517] border transition-all cursor-pointer flex flex-col justify-between hover:scale-[1.02] active:scale-98 shadow-sm ${
                      qtyInCart > 0
                        ? 'border-purple-400 bg-[#14082c] shadow-lg shadow-purple-900/30 ring-1 ring-purple-400/50'
                        : 'border-purple-500/20 hover:border-purple-400/60 hover:bg-[#120726]'
                    }`}
                  >
                    {/* Badge if item is in cart */}
                    {qtyInCart > 0 && (
                      <span className="absolute -top-1.5 -right-1.5 bg-gradient-to-r from-red-600 to-purple-600 text-white text-[10px] font-black w-6 h-6 rounded-full flex items-center justify-center shadow-lg ring-2 ring-[#040108] z-10">
                        x{qtyInCart}
                      </span>
                    )}

                    <div className="space-y-1">
                      <div className="flex items-start justify-between gap-1">
                        <h4 className="font-black text-xs sm:text-sm text-white uppercase tracking-tight leading-tight line-clamp-2 group-hover:text-purple-200">
                          {item.name}
                        </h4>
                      </div>

                      {item.desc && (
                        <p className="text-[10px] text-slate-400 font-medium line-clamp-2 leading-tight">
                          {item.desc}
                        </p>
                      )}
                    </div>

                    <div className="pt-2.5 mt-1 border-t border-purple-500/15 flex items-center justify-between gap-1">
                      <div className="flex items-baseline gap-0.5">
                        <span className="text-[10px] font-bold text-purple-400">$</span>
                        <span className="text-base sm:text-lg font-black text-white font-mono tracking-tight">
                          {item.price}
                        </span>
                      </div>

                      <div className="flex items-center gap-1">
                        {item.isMeter && (
                          <span className="text-[8px] font-black uppercase px-1.5 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-500/30">
                            Metro
                          </span>
                        )}
                        {item.isPortion && (
                          <span className="text-[8px] font-black uppercase px-1.5 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-500/30">
                            Porción
                          </span>
                        )}
                        {requiresToppings ? (
                          <span className="p-1 rounded-lg bg-purple-950/80 text-purple-300 border border-purple-500/40 text-[9px] font-black uppercase flex items-center gap-0.5">
                            <Icon name="tune" size={11} /> Gustos
                          </span>
                        ) : (
                          <span className="w-6 h-6 rounded-lg bg-purple-600 group-hover:bg-purple-500 text-white flex items-center justify-center shadow-xs">
                            <Icon name="add" size={14} />
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* RIGHT PANEL: LIVE COMANDA / TICKET (ALL-IN-ONE SINGLE SCREEN)             */}
      {/* ========================================================================= */}
      <div className={`
        w-full lg:w-[48%] xl:w-[50%] 2xl:w-[50%] shrink-0 flex flex-col h-full bg-[#070312] overflow-hidden border-l border-purple-500/25
        fixed inset-0 z-50 lg:static lg:z-auto transition-transform duration-300
        ${showMobileComanda ? 'translate-y-0' : 'translate-y-full lg:translate-y-0'}
      `}>
        {/* Header of Comanda: Status, Type of Service & Close for Mobile */}
        <div className="px-3.5 py-2.5 bg-[#090317] border-b border-purple-500/25 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-purple-600/30 border border-purple-500/50 flex items-center justify-center text-purple-300">
              <Icon name="receipt_long" size={16} />
            </div>
            <div>
              <div className="text-xs font-black uppercase text-white tracking-wider flex items-center gap-1.5">
                <span>{editingOrder ? `Editando Comanda #${editingOrder.id}` : 'Comanda en Vivo'}</span>
                {editingOrder && (
                  <span className="text-[8px] font-black px-1.5 py-0.2 bg-amber-500 text-slate-950 rounded uppercase">
                    Modo Edición
                  </span>
                )}
              </div>
              <div className="text-[9.5px] font-bold text-slate-400 uppercase">
                {totalItemCount} {totalItemCount === 1 ? 'producto' : 'productos'} cargados
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Close button for mobile modal */}
            <button
              type="button"
              onClick={() => setShowMobileComanda(false)}
              className="lg:hidden p-1.5 text-slate-400 hover:text-white rounded-lg bg-white/5"
            >
              <Icon name="close" size={18} />
            </button>
          </div>
        </div>

        {/* Scrollable Comanda Configuration Body */}
        <div className="flex-1 overflow-y-auto px-2.5 py-1.5 space-y-2 custom-scrollbar">
          {/* SECTION 1: ORDER TYPE / DESTINATION (MESA, DELIVERY, MOSTRADOR) */}
          <div className="p-2 bg-[#0d061e] border border-purple-500/25 rounded-xl space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-[9.5px] font-black uppercase tracking-wider text-purple-300 flex items-center gap-1">
                <Icon name="alt_route" size={12} className="text-purple-400" />
                <span>1. Destino del Pedido</span>
              </label>
              <span className="text-[8.5px] font-black px-1.5 py-0.2 rounded-full bg-purple-950 text-purple-200 border border-purple-500/40 uppercase">
                {orderType}
              </span>
            </div>

            {/* 3 Compact Order Type Buttons */}
            <div className="grid grid-cols-3 gap-1">
              {ORDER_TYPES.map(t => {
                const isSelected = orderType.toLowerCase() === t.id.toLowerCase();
                return (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => {
                      setOrderType(t.id);
                      if (t.id === 'Mesa' && !clientInfo.tableNumber) {
                        setClientInfo((prev: any) => ({ ...prev, tableNumber: 1 }));
                      }
                    }}
                    className={`py-1.5 px-1.5 rounded-lg font-black text-[9px] uppercase transition-all flex items-center justify-center gap-1 border cursor-pointer ${
                      isSelected
                        ? `bg-gradient-to-r ${t.color} text-white border-white/40 shadow-sm shadow-purple-900/40 ring-1 ring-purple-400/50 scale-[1.01]`
                        : 'bg-[#06020e] text-slate-400 hover:text-white border-purple-500/20 hover:bg-white/5'
                    }`}
                  >
                    <Icon name={t.icon} size={13} />
                    <span className="leading-tight text-center truncate">{t.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Sub-Panel: Dynamic details based on order type */}
            {/* A) IF MESA: SELECT TABLE FROM 1 TO 20 */}
            {orderType === 'Mesa' && (
              <div className="pt-2 border-t border-purple-500/20 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[9.5px] font-black text-blue-300 uppercase flex items-center gap-1">
                    <Icon name="table_restaurant" size={13} />
                    <span>Seleccionar Mesa (1 al 20):</span>
                  </span>
                  <span className="text-[10px] font-black text-white font-mono bg-blue-600 px-2 py-0.2 rounded-md">
                    MESA #{clientInfo.tableNumber || 1}
                  </span>
                </div>

                {/* 20 Table Grid (2 rows of 10) */}
                <div className="grid grid-cols-5 sm:grid-cols-10 gap-1">
                  {Array.from({ length: 20 }, (_, i) => i + 1).map(num => {
                    const isSelected = String(clientInfo.tableNumber) === String(num);
                    return (
                      <button
                        key={num}
                        type="button"
                        onClick={() => setClientInfo((prev: any) => ({ ...prev, tableNumber: num }))}
                        className={`py-1.5 rounded-lg font-black text-xs font-mono transition-all cursor-pointer border ${
                          isSelected
                            ? 'bg-blue-600 text-white border-blue-400 shadow-md scale-105 ring-2 ring-blue-400/60'
                            : 'bg-[#06020e] text-slate-300 border-purple-500/20 hover:border-blue-400 hover:text-white'
                        }`}
                      >
                        #{num}
                      </button>
                    );
                  })}
                </div>

                {/* Mozo / Nombre de Referencia de Mesa */}
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <div className="space-y-0.5">
                    <label className="text-[9px] font-black text-slate-400 uppercase">Referencia / Comensal</label>
                    <input
                      type="text"
                      placeholder="Ej: Familia Gómez..."
                      value={clientInfo.name}
                      onChange={e => setClientInfo({ ...clientInfo, name: e.target.value.toUpperCase() })}
                      className="w-full p-2 bg-[#06020e] border border-purple-500/30 text-white rounded-xl text-xs font-black uppercase outline-none focus:border-blue-400"
                    />
                  </div>
                  <div className="space-y-0.5">
                    <label className="text-[9px] font-black text-slate-400 uppercase">Mozo Asignado</label>
                    <select
                      value={clientInfo.assignedWaiter || 'Moza 1'}
                      onChange={e => setClientInfo({ ...clientInfo, assignedWaiter: e.target.value })}
                      className="w-full p-2 bg-[#06020e] border border-purple-500/30 text-white rounded-xl text-xs font-black outline-none focus:border-blue-400 cursor-pointer"
                    >
                      <option value="Moza 1">Moza 1</option>
                      <option value="Mozo 2">Mozo 2</option>
                      <option value="Mozo 3">Mozo 3</option>
                      <option value="Barra / Encargado">Barra / Encargado</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* B) IF DELIVERY / ENVÍO: CLIENT DATA + DELIVERY DRIVER */}
            {['envío', 'delivery'].includes(orderType.toLowerCase()) && (
              <div className="pt-2 border-t border-purple-500/20 space-y-2">
                {/* Client Search / Phone & Name with Fresh Database Synchronization */}
                <ClientContactLookup
                  allClients={allClients}
                  clientInfo={clientInfo}
                  setClientInfo={setClientInfo}
                  orderType={orderType}
                  setOrderType={setOrderType}
                  mode="delivery"
                  showMessage={showMessage}
                  db={db}
                  appId={appId}
                />

                {/* Address & Zone */}
                <div className="grid grid-cols-3 gap-2">
                  <div className="col-span-2 space-y-0.5">
                    <label className="text-[9px] font-black text-slate-400 uppercase">Dirección de Entrega</label>
                    <input
                      type="text"
                      placeholder="Calle, número, esq / apto"
                      value={clientInfo.address}
                      onChange={e => setClientInfo({ ...clientInfo, address: e.target.value.toUpperCase() })}
                      className="w-full p-2 bg-[#06020e] border border-purple-500/30 text-white rounded-xl text-xs font-black uppercase outline-none focus:border-purple-400"
                    />
                  </div>

                  <div className="space-y-0.5">
                    <label className="text-[9px] font-black text-slate-400 uppercase">Zona / Barrio</label>
                    <input
                      type="text"
                      placeholder="Pocitos..."
                      value={clientInfo.zone}
                      onChange={e => setClientInfo({ ...clientInfo, zone: e.target.value.toUpperCase() })}
                      className="w-full p-2 bg-[#06020e] border border-purple-500/30 text-white rounded-xl text-xs font-black uppercase outline-none focus:border-purple-400"
                    />
                  </div>
                </div>

                {/* Delivery Driver Selector */}
                <div className="p-2 bg-[#090214] border border-purple-500/30 rounded-xl space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-[9.5px] font-black text-amber-300 uppercase flex items-center gap-1">
                      <Icon name="two_wheeler" size={13} />
                      <span>Repartidor Asignado:</span>
                    </label>
                    <span className="text-[8.5px] font-black text-purple-300 bg-purple-950 px-1.5 py-0.2 rounded-md border border-purple-500/30">
                      Sugerido: {suggestedDriver.name}
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-1.5">
                    {DRIVERS.map(d => {
                      const isSelected = (clientInfo.assignedDriver || '').toLowerCase() === d.name.toLowerCase();
                      const isSuggested = suggestedDriver.name.toLowerCase() === d.name.toLowerCase();

                      return (
                        <button
                          key={d.id}
                          type="button"
                          onClick={() => setClientInfo({ ...clientInfo, assignedDriver: d.name, assignedDriverId: d.id })}
                          className={`py-1.5 px-1 rounded-xl font-black text-[10px] uppercase transition-all flex flex-col items-center justify-center border cursor-pointer ${
                            isSelected
                              ? 'bg-amber-600 text-white border-amber-400 shadow-md ring-2 ring-amber-400/50'
                              : isSuggested
                              ? 'bg-[#1a0c2e] text-purple-200 border-purple-500/50 hover:bg-purple-900/50'
                              : 'bg-[#06020e] text-slate-400 hover:text-white border-purple-500/20 hover:bg-white/5'
                          }`}
                        >
                          <span>{d.label}</span>
                          {isSuggested && !isSelected && (
                            <span className="text-[7.5px] text-purple-400 font-bold">Turno</span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Optional Google Map Preview Toggle */}
                {clientInfo.address && clientInfo.address.length > 2 && (
                  <button
                    type="button"
                    onClick={() => setShowMapModal(!showMapModal)}
                    className="w-full py-1 text-[9px] font-black uppercase text-blue-300 bg-blue-950/40 hover:bg-blue-950 border border-blue-500/30 rounded-lg flex items-center justify-center gap-1 cursor-pointer transition-colors"
                  >
                    <Icon name="map" size={12} />
                    <span>{showMapModal ? 'Ocultar Mapa' : 'Ver Ubicación en Mapa'}</span>
                  </button>
                )}

                {showMapModal && clientInfo.address && (
                  <GoogleDeliveryMap
                    address={clientInfo.address}
                    zone={clientInfo.zone}
                    clientName={clientInfo.name}
                    clientPhone={clientInfo.phone}
                    orderDetails={{
                      itemsSummary: cart.map(i => `• ${i.quantity || 1}x ${i.name}`).join('\n'),
                      totalAmount: cartTotal,
                      paymentMethod,
                      cashProvided: parseFloat(cashProvided) || undefined,
                      changeDue: Math.max(0, (parseFloat(cashProvided) || 0) - cartTotal)
                    }}
                    showMessage={showMessage}
                  />
                )}
              </div>
            )}

            {/* C) IF MOSTRADOR: CLIENT CONTACT & PROFILE FROM DB */}
            {orderType === 'Local' && (
              <div className="pt-2 border-t border-purple-500/20">
                <ClientContactLookup
                  allClients={allClients}
                  clientInfo={clientInfo}
                  setClientInfo={setClientInfo}
                  orderType={orderType}
                  setOrderType={setOrderType}
                  mode="counter"
                  showMessage={showMessage}
                  db={db}
                  appId={appId}
                />
              </div>
            )}
          </div>

          {/* SECTION 2: ITEMS IN CART (LO SELECCIONADO / LO CARGADO) */}
          <div className="p-2 bg-[#0d061e] border border-purple-500/25 rounded-xl space-y-1.5">
            <div className="flex items-center justify-between border-b border-purple-500/20 pb-1">
              <label className="text-[9.5px] font-black uppercase tracking-wider text-purple-300 flex items-center gap-1">
                <Icon name="shopping_cart" size={12} className="text-purple-400" />
                <span>2. Productos Cargados</span>
              </label>
              <div className="flex items-center gap-2">
                {cart.length > 0 && (
                  <button
                    type="button"
                    onClick={clearForm}
                    className="text-[8.5px] font-black text-red-400 hover:text-red-300 uppercase hover:underline cursor-pointer"
                  >
                    Vaciar
                  </button>
                )}
                <span className="text-[8.5px] font-mono font-black text-white bg-purple-950 px-1.5 py-0.2 rounded-full border border-purple-500/40">
                  {totalItemCount} {totalItemCount === 1 ? 'ítem' : 'ítems'}
                </span>
              </div>
            </div>

            {cart.length === 0 ? (
              <div className="py-2.5 px-3 text-center border border-dashed border-purple-500/20 rounded-lg space-y-0.5 bg-[#06020e]">
                <Icon name="touch_app" size={18} className="text-purple-400/50 mx-auto" />
                <p className="text-[11px] font-bold text-slate-400">Comanda vacía</p>
                <p className="text-[9px] text-slate-500">Toca los productos del menú para cargarlos al instante.</p>
              </div>
            ) : (
              <div className="space-y-1 max-h-56 sm:max-h-64 overflow-y-auto custom-scrollbar pr-0.5">
                {cart.map((item, idx) => {
                  const linePrice = Math.round((item.finalPrice || item.price) * (item.quantity || 1));
                  return (
                    <div
                      key={item.cartId || idx}
                      className="p-1.5 bg-[#080314] border border-purple-500/20 rounded-lg flex items-center justify-between gap-1.5 hover:border-purple-400/50 transition-colors"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1">
                          <span className="font-black text-[11px] text-white uppercase truncate">
                            {item.name}
                          </span>
                          {item.isPortion && (
                            <span className="text-[7px] px-1 bg-blue-950 text-blue-300 rounded font-black">Porción</span>
                          )}
                        </div>

                        {/* Selected Toppings Display */}
                        {item.selectedToppings && item.selectedToppings.length > 0 && (
                          <div className="text-[9px] font-bold text-purple-300 truncate">
                            ★ {item.selectedToppings.map((t: any) => t.name).join(' • ')}
                          </div>
                        )}

                        <div className="text-[9px] text-slate-400 font-mono">
                          ${item.finalPrice || item.price} c/u
                        </div>
                      </div>

                      {/* Quantity Modifier & Line Total */}
                      <div className="flex items-center gap-1.5 shrink-0">
                        <div className="flex items-center bg-[#05020c] border border-purple-500/30 rounded-md overflow-hidden">
                          <button
                            type="button"
                            onClick={() => updateQuantity(item.cartId, -1)}
                            className="w-5 h-5 flex items-center justify-center text-[10px] font-black text-slate-300 hover:text-white hover:bg-purple-900/50 cursor-pointer"
                          >
                            -
                          </button>
                          <span className="w-5 text-center text-[10px] font-black font-mono text-white">
                            {item.quantity || 1}
                          </span>
                          <button
                            type="button"
                            onClick={() => updateQuantity(item.cartId, 1)}
                            className="w-5 h-5 flex items-center justify-center text-[10px] font-black text-purple-300 hover:text-white hover:bg-purple-600 cursor-pointer"
                          >
                            +
                          </button>
                        </div>

                        <div className="w-12 text-right font-black text-[11px] text-white font-mono">
                          ${linePrice}
                        </div>

                        <button
                          type="button"
                          onClick={() => updateQuantity(item.cartId, -(item.quantity || 1))}
                          className="p-0.5 text-slate-500 hover:text-red-400 transition-colors cursor-pointer"
                          title="Eliminar producto"
                        >
                          <Icon name="delete" size={13} />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* SECTION 3: NOTES & KITCHEN OBSERVATIONS (QUICK CHIPS REMOVED) */}
          <div className="p-2 bg-[#0d061e] border border-purple-500/25 rounded-xl space-y-1">
            <label className="text-[9.5px] font-black uppercase tracking-wider text-purple-300 flex items-center gap-1">
              <Icon name="edit_note" size={12} className="text-purple-400" />
              <span>3. Observaciones para Cocina</span>
            </label>

            <input
              type="text"
              placeholder="Ej: Bien tostada, sin orégano, entregar antes de las 21hs..."
              value={orderNotes}
              onChange={e => setOrderNotes(e.target.value)}
              className="w-full p-1.5 bg-[#06020e] border border-purple-500/30 text-white rounded-lg text-xs font-medium outline-none focus:border-purple-400"
            />
          </div>

          {/* SECTION 4: PAYMENT METHODS & CASH CALCULATOR */}
          <div className="p-2 bg-[#0d061e] border border-purple-500/25 rounded-xl space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-[9.5px] font-black uppercase tracking-wider text-purple-300 flex items-center gap-1">
                <Icon name="payments" size={12} className="text-purple-400" />
                <span>4. Forma de Pago</span>
              </label>
              <span className="text-[8.5px] font-black px-1.5 py-0.2 rounded bg-purple-950 text-purple-200 border border-purple-500/40">
                {paymentMethod}
              </span>
            </div>

            {/* Payment Method 1-Click Buttons */}
            <div className="grid grid-cols-5 gap-1">
              {PAYMENT_METHODS.map(pm => {
                const isSelected = paymentMethod.toLowerCase() === pm.id.toLowerCase();
                return (
                  <button
                    key={pm.id}
                    type="button"
                    onClick={() => setPaymentMethod(pm.id)}
                    className={`py-1 px-0.5 rounded-lg font-black text-[8.5px] uppercase transition-all flex flex-col items-center justify-center gap-0.5 border cursor-pointer ${
                      isSelected
                        ? 'bg-purple-600 text-white border-purple-300 shadow-sm shadow-purple-600/40 ring-1 ring-purple-400/50 scale-[1.01]'
                        : 'bg-[#06020e] text-slate-400 hover:text-white border-purple-500/20 hover:bg-white/5'
                    }`}
                  >
                    <span className="text-[11px]">{pm.badge}</span>
                    <span className="truncate w-full text-center">{pm.label}</span>
                  </button>
                );
              })}
            </div>

            {/* If Cash: Quick Denominations + Change Due Calculation */}
            {paymentMethod === 'Efectivo' && (
              <div className="p-1.5 bg-[#06020e] border border-purple-500/20 rounded-lg space-y-1">
                <div className="flex items-center justify-between gap-1">
                  <div className="flex-1 space-y-0.5">
                    <label className="text-[8px] font-black text-slate-400 uppercase">Paga con $</label>
                    <input
                      type="number"
                      placeholder="Monto entregado..."
                      value={cashProvided}
                      onChange={e => setCashProvided(e.target.value)}
                      className="w-full p-1 bg-[#0c051a] border border-purple-500/30 text-white rounded-md text-xs font-black font-mono outline-none focus:border-purple-400"
                    />
                  </div>

                  {/* Vuelto Indicator */}
                  <div className="flex-1 text-right">
                    <div className="text-[8px] font-black text-slate-400 uppercase">Vuelto a Entregar</div>
                    <div className={`text-xs font-black font-mono ${changeDue > 0 ? 'text-emerald-400' : missingCash > 0 ? 'text-red-400' : 'text-slate-300'}`}>
                      {changeDue > 0 ? `$${changeDue}` : missingCash > 0 ? `Falta $${missingCash}` : '$0'}
                    </div>
                  </div>
                </div>

                {/* Quick Cash Chips */}
                <div className="flex flex-wrap gap-1">
                  <button
                    type="button"
                    onClick={() => setCashProvided(String(cartTotal))}
                    className="px-1.5 py-0.2 bg-purple-950/60 hover:bg-purple-900 border border-purple-500/30 text-purple-300 rounded text-[8.5px] font-black font-mono cursor-pointer"
                  >
                    Exacto (${cartTotal})
                  </button>
                  {[500, 1000, 2000, 5000].map(amt => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setCashProvided(String(amt))}
                      className="px-1.5 py-0.2 bg-[#0d061c] hover:bg-[#1a0c38] border border-purple-500/20 text-slate-300 rounded text-[8.5px] font-black font-mono cursor-pointer"
                    >
                      ${amt}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* ========================================================================= */}
        {/* FOOTER: TOTAL + OBLIGATORY TICKET PRINTING CONTROL BEFORE DISPATCHING    */}
        {/* ========================================================================= */}
        <div className="p-2 sm:p-2.5 bg-[#080214] border-t border-purple-500/30 space-y-1.5 shrink-0 shadow-2xl">
          {/* Total Row */}
          <div className="flex items-center justify-between px-0.5">
            <div>
              <span className="text-[9.5px] font-black uppercase text-slate-400 tracking-wider block">Total a Pagar</span>
              <span className="text-[8.5px] font-bold text-purple-400">{orderType} • {paymentMethod}</span>
            </div>
            <div className="text-right">
              <span className="text-xl sm:text-2xl font-black text-white font-mono tracking-tight text-purple-200">
                ${cartTotal}
              </span>
            </div>
          </div>

          {/* OBLIGATORY PRINT NOTICE & ENFORCEMENT */}
          <div className={`py-1 px-2 rounded-lg text-center border transition-all ${
            ticketPrinted 
              ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200' 
              : 'bg-amber-950/40 border-amber-500/40 text-amber-200'
          }`}>
            <div className="flex items-center justify-center gap-1 text-[9px] font-black uppercase">
              {ticketPrinted ? (
                <>
                  <Icon name="check_circle" size={13} className="text-emerald-400" />
                  <span>✓ Comanda impresa correctamente. Lista para pasar a KDS.</span>
                </>
              ) : (
                <>
                  <Icon name="warning" size={13} className="text-amber-400 animate-pulse" />
                  <span>⚠️ Obligatorio imprimir comanda antes de salir a KDS</span>
                </>
              )}
            </div>
          </div>

          {/* ACTION BUTTONS GRID */}
          <div className="grid grid-cols-2 gap-1.5">
            {/* Button 1: Print Ticket (Marks as printed) */}
            <button
              type="button"
              onClick={() => handlePrintTicket()}
              disabled={cart.length === 0}
              className={`py-2 px-2 rounded-xl font-black uppercase text-[10.5px] flex items-center justify-center gap-1.5 transition-all cursor-pointer border ${
                cart.length === 0
                  ? 'bg-slate-900 border-slate-800 text-slate-600 cursor-not-allowed'
                  : ticketPrinted
                  ? 'bg-[#150a2b] hover:bg-[#200f42] text-purple-200 border-purple-500/40 shadow-sm'
                  : 'bg-gradient-to-r from-purple-700 to-indigo-700 hover:from-purple-600 hover:to-indigo-600 text-white border-purple-400 shadow-md shadow-purple-900/50 ring-1 ring-purple-400/40 animate-pulse'
              }`}
            >
              <Icon name="print" size={14} />
              <span>{ticketPrinted ? 'Re-imprimir' : '1. Imprimir Ticket'}</span>
            </button>

            {/* Button 2: Send to Kitchen (KDS) */}
            <button
              type="button"
              onClick={() => handleDispatchToKds(false)}
              disabled={cart.length === 0 || isSubmitting}
              className={`py-2 px-2 rounded-xl font-black uppercase text-[10.5px] flex items-center justify-center gap-1.5 transition-all cursor-pointer border ${
                cart.length === 0 || isSubmitting
                  ? 'bg-slate-900 border-slate-800 text-slate-600 cursor-not-allowed'
                  : ticketPrinted
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white border-emerald-400 shadow-md shadow-emerald-900/50 ring-1 ring-emerald-400/60 scale-[1.01]'
                  : 'bg-purple-950/60 hover:bg-purple-900 text-purple-300 border-purple-500/30'
              }`}
              title={!ticketPrinted ? "Se imprimirá automáticamente antes de enviar a KDS" : "Enviar comanda a cocina"}
            >
              {isSubmitting ? (
                <>
                  <Icon name="sync" size={14} className="animate-spin" />
                  <span>Enviando...</span>
                </>
              ) : (
                <>
                  <Icon name="rocket_launch" size={14} />
                  <span>2. Enviar a KDS</span>
                </>
              )}
            </button>
          </div>

          {/* ALL-IN-ONE ULTRA-FAST ACTION: PRINT & SEND TO KDS IN 1 CLICK */}
          <button
            type="button"
            onClick={() => handleDispatchToKds(true)}
            disabled={cart.length === 0 || isSubmitting}
            className={`w-full py-2 px-2.5 rounded-xl font-black uppercase text-[11px] flex items-center justify-center gap-1.5 transition-all cursor-pointer border ${
              cart.length === 0 || isSubmitting
                ? 'bg-slate-900 border-slate-800 text-slate-600 cursor-not-allowed'
                : 'bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-600 hover:from-purple-500 hover:to-indigo-500 text-white border-purple-300 shadow-lg shadow-purple-600/40 hover:scale-[1.005] active:scale-98'
            }`}
          >
            <Icon name="bolt" size={15} className="text-yellow-300" />
            <span>⚡ Imprimir y Enviar a Cocina (1 Clic)</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* MODALS: WHATSAPP PARSER & OBJECTIONS                                      */}
      {/* ========================================================================= */}
      {isWhatsAppParserOpen && (
        <WhatsAppOrderParserModal
          isOpen={isWhatsAppParserOpen}
          onClose={() => setIsWhatsAppParserOpen(false)}
          menu={menu}
          allMenuItems={allMenuItems}
          onApplyParsedOrder={handleApplyWhatsAppOrder}
          showMessage={showMessage}
        />
      )}

      {isObjectionsOpen && (
        <CustomerObjectionsModal
          isOpen={isObjectionsOpen}
          onClose={() => setIsObjectionsOpen(false)}
          allMenuItems={allMenuItems}
          onAddQuickItem={(item, toppings, qty) => addToCart(item, toppings, qty || 1)}
          onAddNote={handleAddNoteChip}
          showMessage={showMessage}
        />
      )}
    </div>
  );
};
